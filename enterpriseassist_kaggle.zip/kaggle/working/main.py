from src.agents.orchestrator import Orchestrator
from src.memory.session_manager import SessionManager
from src.memory.long_term_memory import LongTermMemory
from src.observability.logger import log_event
from src.eval.evaluator import Evaluator

def run_demo():
    orch = Orchestrator()
    sess = SessionManager()
    ltm = LongTermMemory()
    evaluator = Evaluator()

    msg = "I need a refund"
    response = orch.route(msg)

    sess.add("last_query", msg)
    ltm.save(msg)
    log_event({"user_msg": msg, "agent_response": response})

    print("Response:", response)
    print("Memory:", ltm.get_all())
    print("Eval Score:", evaluator.score(response))

run_demo()
