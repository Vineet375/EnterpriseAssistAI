class Evaluator:
    def score(self, output):
        return 0.9  # demo fixed score
