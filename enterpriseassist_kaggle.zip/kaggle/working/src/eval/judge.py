def judge_answer(ref,cand):
    r=set(ref.lower().split()); c=set(cand.lower().split())
    score=int(100*len(r&c)/max(1,len(r)))
    return max(0,min(10,score//10))
