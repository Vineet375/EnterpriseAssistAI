class LongTermMemory:
    def __init__(self):
        self.storage = []

    def save(self, msg):
        self.storage.append(msg)

    def get_all(self):
        return self.storage
