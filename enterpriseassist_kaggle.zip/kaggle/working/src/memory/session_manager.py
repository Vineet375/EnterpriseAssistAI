class SessionManager:
    def __init__(self):
        self.session = {}

    def add(self, key, value):
        self.session[key] = value

    def get(self, key):
        return self.session.get(key)
