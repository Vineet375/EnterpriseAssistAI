def search_stub(query):
    return {"results": ["demo1", "demo2"]}