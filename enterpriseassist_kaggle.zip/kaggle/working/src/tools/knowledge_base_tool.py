def kb_lookup(query):
    return {"result": "Sample knowledge base result"}