def run_diagnostics(ctx):
    return {"tool":"diagnostics","output":"Diagnostics OK: token expired."}
