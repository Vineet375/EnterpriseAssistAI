def create_ticket(user_msg):
    return {"ticket_id": 12345}