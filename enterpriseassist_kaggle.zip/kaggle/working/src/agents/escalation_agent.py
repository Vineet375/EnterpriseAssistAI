class EscalationAgent:
    def __init__(self, name="escalation"):
        self.name = name

    def handle(self, msg):
        return {
            "action": "respond",
            "text": "Your issue has been escalated to Level 2.",
            "tool": None
        }
