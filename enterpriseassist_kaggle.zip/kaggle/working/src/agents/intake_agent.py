class IntakeAgent:
    def __init__(self, name="intake"):
        self.name = name

    def handle(self, text):
        text = text.lower()
        if any(k in text for k in ["refund", "charge", "billing"]):
            return {"intent": "billing", "confidence": 0.9}
        if any(k in text for k in ["login", "403", "error"]):
            return {"intent": "diagnostic", "confidence": 0.9}
        return {"intent": "support", "confidence": 0.6}
