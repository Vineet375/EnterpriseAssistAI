class SupportAgent:
    def __init__(self, name="support"):
        self.name = name

    def handle(self, msg):
        return {
            "action": "respond",
            "text": f"Based on user message: {msg}",
            "tool": None
        }
