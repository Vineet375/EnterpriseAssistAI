from src.agents.intake_agent import IntakeAgent
from src.agents.support_agent import SupportAgent
from src.agents.escalation_agent import EscalationAgent

class Orchestrator:
    def __init__(self):
        self.intake = IntakeAgent()
        self.support = SupportAgent()
        self.escalation = EscalationAgent()

    def route(self, msg):
        intent = self.intake.handle(msg)["intent"]
        if intent == "billing":
            return self.support.handle(msg)
        if intent == "diagnostic":
            return self.escalation.handle(msg)
        return self.support.handle(msg)
