import time, json

def log_event(event):
    with open('/kaggle/working/logs.json', 'a') as f:
        f.write(json.dumps({"time": time.time(), "event": event}) + '\n')
